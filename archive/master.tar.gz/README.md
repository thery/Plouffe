# Plouffe
Computing Pi decimal using Plouffe Formula in Coq
